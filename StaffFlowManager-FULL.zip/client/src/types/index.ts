// Staff types
export type StaffStatus = "active" | "inactive" | "on leave";

export interface Staff {
  id: number;
  name: string;
  email: string;
  position: string;
  department: string;
  status: StaffStatus;
}

// Activity types
export interface Activity {
  id: number;
  type: string;
  message: string;
  timeAgo: string;
}

// Health check types
export type ServiceStatus = "operational" | "degraded" | "down";

export interface HealthService {
  name: string;
  status: ServiceStatus;
  lastChecked: string;
  responseTime: number;
}

export interface HealthCheckResponse {
  status: "operational" | "degraded";
  message: string;
  lastFullCheck: string;
  services: HealthService[];
}
