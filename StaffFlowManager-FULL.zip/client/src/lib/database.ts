// Database client utility for Supabase integration
// This is a client-side utility for database operations needed in the frontend

// For client-side safety, we don't directly access the database
// Instead we use the REST API endpoints created in the server

export const getServiceStatus = async () => {
  try {
    const response = await fetch('/api/health');
    if (!response.ok) throw new Error('Failed to fetch health status');
    return await response.json();
  } catch (error) {
    console.error('Error fetching service status:', error);
    return [];
  }
};

export const getStaffList = async () => {
  try {
    const response = await fetch('/api/staff');
    if (!response.ok) throw new Error('Failed to fetch staff list');
    return await response.json();
  } catch (error) {
    console.error('Error fetching staff list:', error);
    return { staff: [], total: 0 };
  }
};