import { useQuery } from "@tanstack/react-query";
import { Staff } from "@/types";

// Mock data for now, would be replaced with actual API calls
const mockStaff: Staff[] = [
  {
    id: 1,
    name: "Jane Doe",
    email: "jane.doe@example.com",
    position: "Senior Developer",
    department: "Engineering",
    status: "active"
  },
  {
    id: 2,
    name: "John Smith",
    email: "john.smith@example.com",
    position: "UI Designer",
    department: "Design",
    status: "active"
  },
  {
    id: 3,
    name: "Alice Johnson",
    email: "alice.j@example.com",
    position: "Project Manager",
    department: "Management",
    status: "on leave"
  },
  {
    id: 4,
    name: "Robert Brown",
    email: "robert.b@example.com",
    position: "DevOps Engineer",
    department: "Infrastructure",
    status: "inactive"
  }
];

export const useStaff = () => {
  // This would be replaced with an actual API query
  const { data, isLoading, isError } = useQuery<{ staff: Staff[], total: number }>({
    queryKey: ["/api/staff"],
    queryFn: async () => {
      // Simulate API call
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve({
            staff: mockStaff,
            total: 87
          });
        }, 500);
      });
    }
  });
  
  return {
    staff: data?.staff || [],
    totalStaff: data?.total || 0,
    isLoading,
    isError
  };
};
