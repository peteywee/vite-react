import { useQuery } from "@tanstack/react-query";
import { Activity } from "@/types";

// Mock data for now, would be replaced with actual API calls
const mockActivities: Activity[] = [
  {
    id: 1,
    type: "staff_added",
    message: "New staff member <strong>Jane Doe</strong> added",
    timeAgo: "2h ago"
  },
  {
    id: 2,
    type: "profile_updated",
    message: "<strong>John Smith</strong> updated their profile",
    timeAgo: "3h ago"
  },
  {
    id: 3,
    type: "schedule_created",
    message: "New schedule created by <strong>Alice Johnson</strong>",
    timeAgo: "5h ago"
  },
  {
    id: 4,
    type: "health_check",
    message: "System health check completed",
    timeAgo: "8h ago"
  }
];

export const useActivities = () => {
  // This would be replaced with an actual API query
  const { data, isLoading, isError } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
    queryFn: async () => {
      // Simulate API call
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(mockActivities);
        }, 500);
      });
    }
  });
  
  return {
    activities: data || [],
    isLoading,
    isError
  };
};
