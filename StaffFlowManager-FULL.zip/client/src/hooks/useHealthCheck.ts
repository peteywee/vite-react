import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { HealthCheckResponse } from "@/types";

export const useHealthCheck = () => {
  const queryClient = useQueryClient();
  
  // Fetch health data
  const { data, isLoading, isError } = useQuery<HealthCheckResponse>({
    queryKey: ["/api/health"],
  });
  
  // Format the health data
  const healthData = data ? {
    services: data.services,
    lastFullCheck: data.lastFullCheck,
    isAllOperational: data.status === "operational"
  } : undefined;
  
  // Mutation to run a health check
  const { mutate: runHealthCheck, isPending } = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/health/run-check", {});
      return true;
    },
    onSuccess: () => {
      // Invalidate and refetch the health data
      queryClient.invalidateQueries({ queryKey: ["/api/health"] });
    }
  });
  
  return {
    healthData,
    isLoading,
    isError,
    runHealthCheck,
    isPending
  };
};
