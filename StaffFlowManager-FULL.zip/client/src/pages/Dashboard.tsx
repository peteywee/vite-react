import StatsOverview from "@/components/StatsOverview";
import StaffOverview from "@/components/StaffOverview";
import RecentActivity from "@/components/RecentActivity";
import HealthMonitor from "@/components/HealthMonitor";
import { useStaff } from "@/hooks/useStaff";
import { useActivities } from "@/hooks/useActivities";
import { useHealthCheck } from "@/hooks/useHealthCheck";
import { useToast } from "@/hooks/use-toast";

const Dashboard = () => {
  const { staff, totalStaff, isLoading: staffLoading } = useStaff();
  const { activities, isLoading: activitiesLoading } = useActivities();
  const { healthData, isLoading: healthLoading } = useHealthCheck();
  const { toast } = useToast();
  
  const handleAddStaff = () => {
    toast({
      title: "Add Staff",
      description: "The Add Staff functionality is coming soon.",
    });
  };
  
  // Default stats
  const stats = [
    {
      title: "Total Staff",
      value: totalStaff,
      icon: "users",
      iconBgClass: "bg-blue-100 dark:bg-blue-900",
      iconTextClass: "text-primary",
      change: {
        value: "12%",
        positive: true
      }
    },
    {
      title: "Active Schedules",
      value: "42",
      icon: "calendar",
      iconBgClass: "bg-green-100 dark:bg-green-900",
      iconTextClass: "text-secondary",
      change: {
        value: "8%",
        positive: true
      }
    },
    {
      title: "Open Positions",
      value: "14",
      icon: "briefcase",
      iconBgClass: "bg-yellow-100 dark:bg-yellow-900",
      iconTextClass: "text-warning",
      change: {
        value: "5%",
        positive: false
      }
    },
    {
      title: "System Health",
      value: healthData?.isAllOperational ? "100%" : "Degraded",
      icon: "activity",
      iconBgClass: "bg-purple-100 dark:bg-purple-900",
      iconTextClass: "text-accent",
      subtext: healthData?.isAllOperational ? "All systems operational" : "Some systems degraded"
    }
  ];

  return (
    <>
      {/* Stats Overview */}
      <StatsOverview stats={stats} />
      
      {/* Staff Overview and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Staff Overview */}
        <StaffOverview 
          staff={staff} 
          totalStaff={totalStaff} 
          onAddStaff={handleAddStaff} 
        />
        
        {/* Recent Activity */}
        <RecentActivity activities={activities} />
      </div>
      
      {/* API Health Monitor */}
      {healthData && (
        <HealthMonitor 
          services={healthData.services} 
          lastFullCheck={healthData.lastFullCheck}
          isAllOperational={healthData.isAllOperational}
        />
      )}
    </>
  );
};

export default Dashboard;
