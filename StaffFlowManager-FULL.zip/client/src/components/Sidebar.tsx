import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  BarChart, 
  Settings, 
  ShieldCheck, 
  Lock, 
  Activity 
} from "lucide-react";

const Sidebar = () => {
  return (
    <aside className="w-64 bg-white dark:bg-gray-900 shadow-md hidden md:block">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
            <Users className="h-4 w-4" />
          </div>
          <h1 className="text-xl font-semibold">StaffFlowTX</h1>
        </div>
      </div>

      <nav className="p-2">
        <div className="space-y-1">
          <NavLink href="/" icon={<LayoutDashboard className="mr-3 h-4 w-4" />} active>Dashboard</NavLink>
          <NavLink href="/staff" icon={<Users className="mr-3 h-4 w-4" />}>Staff</NavLink>
          <NavLink href="/schedules" icon={<Calendar className="mr-3 h-4 w-4" />}>Schedules</NavLink>
          <NavLink href="/reports" icon={<BarChart className="mr-3 h-4 w-4" />}>Reports</NavLink>
          <NavLink href="/settings" icon={<Settings className="mr-3 h-4 w-4" />}>Settings</NavLink>
        </div>

        <div className="mt-8 pt-4 border-t border-gray-200 dark:border-gray-700">
          <h3 className="px-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">Admin</h3>
          <div className="mt-2 space-y-1">
            <NavLink href="/users" icon={<ShieldCheck className="mr-3 h-4 w-4" />}>User Management</NavLink>
            <NavLink href="/permissions" icon={<Lock className="mr-3 h-4 w-4" />}>Permissions</NavLink>
            <NavLink href="/health-check" icon={<Activity className="mr-3 h-4 w-4" />}>Health Check</NavLink>
          </div>
        </div>
      </nav>
    </aside>
  );
};

interface NavLinkProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  active?: boolean;
}

const NavLink = ({ href, icon, children, active }: NavLinkProps) => {
  return (
    
    <a href={href} className={cn(
        "flex items-center p-2 rounded-md",
        active ? "bg-primary bg-opacity-10 text-primary" : "hover:bg-gray-100 dark:hover:bg-gray-800"
      )}>
        {icon}
        {children}
      
    </a>
    
  );
};

export default Sidebar;