import { 
  Card, 
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Plus, Filter, Edit, MoreVertical } from "lucide-react";
import { Staff, StaffStatus } from "@/types";

interface StaffOverviewProps {
  staff: Staff[];
  totalStaff: number;
  onAddStaff?: () => void;
}

const statusColorMap: Record<StaffStatus, string> = {
  active: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  inactive: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  "on leave": "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
};

const getInitials = (name: string) => {
  return name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase();
};

const getAvatarColor = (name: string) => {
  const colors = [
    "bg-blue-200 text-blue-600",
    "bg-green-200 text-green-600",
    "bg-purple-200 text-purple-600",
    "bg-red-200 text-red-600"
  ];
  
  // Simple hash function to pick a color based on name
  const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[hash % colors.length];
};

const StaffOverview = ({ staff, totalStaff, onAddStaff }: StaffOverviewProps) => {
  return (
    <Card className="col-span-full lg:col-span-2">
      <CardHeader className="border-b border-gray-200 dark:border-gray-700 flex flex-row items-center justify-between p-6">
        <CardTitle className="text-lg font-semibold">Staff Overview</CardTitle>
        <div className="flex space-x-2">
          <Button variant="ghost" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <Button size="sm" onClick={onAddStaff}>
            <Plus className="h-4 w-4 mr-1" />
            <span>Add Staff</span>
          </Button>
        </div>
      </CardHeader>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 dark:bg-gray-800 text-xs uppercase text-gray-500 dark:text-gray-400">
            <tr>
              <th className="px-6 py-3 text-left">Name</th>
              <th className="px-6 py-3 text-left">Position</th>
              <th className="px-6 py-3 text-left">Department</th>
              <th className="px-6 py-3 text-left">Status</th>
              <th className="px-6 py-3 text-left">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {staff.map((member) => (
              <tr key={member.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Avatar className={`mr-3 ${getAvatarColor(member.name)}`}>
                      <AvatarFallback>{getInitials(member.name)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{member.name}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">{member.email}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>{member.position}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>{member.department}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <Badge variant="outline" className={statusColorMap[member.status]}>
                    {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                  </Badge>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="icon">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <CardFooter className="border-t border-gray-200 dark:border-gray-700 flex items-center justify-between p-4">
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Showing <span className="font-medium">{staff.length}</span> of <span className="font-medium">{totalStaff}</span> staff members
        </div>
        <div className="flex space-x-1">
          <Button variant="outline" size="sm" disabled>
            Previous
          </Button>
          <Button variant="outline" size="sm">
            Next
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default StaffOverview;
