import { 
  Card, 
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Repeat } from "lucide-react";
import { HealthService } from "@/types";
import { useHealthCheck } from "@/hooks/useHealthCheck";
import { formatDistanceToNow } from "date-fns";

interface HealthMonitorProps {
  services: HealthService[];
  lastFullCheck: string;
  isAllOperational: boolean;
}

const HealthMonitor = ({ services, lastFullCheck, isAllOperational }: HealthMonitorProps) => {
  const { runHealthCheck, isPending } = useHealthCheck();

  const formattedLastCheck = new Date(lastFullCheck).toLocaleString('en-US', {
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });

  return (
    <Card>
      <CardHeader className="border-b border-gray-200 dark:border-gray-700 flex flex-row justify-between items-center p-6">
        <CardTitle className="text-lg font-semibold">API Health Monitor</CardTitle>
        <div className="flex items-center space-x-2">
          <span className="flex h-3 w-3 relative">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${isAllOperational ? 'bg-green-400' : 'bg-amber-400'} opacity-75`}></span>
            <span className={`relative inline-flex rounded-full h-3 w-3 ${isAllOperational ? 'bg-green-500' : 'bg-amber-500'}`}></span>
          </span>
          <span className={isAllOperational ? "text-sm text-green-500" : "text-sm text-amber-500"}>
            {isAllOperational ? "All systems operational" : "Some systems degraded"}
          </span>
        </div>
      </CardHeader>

      <CardContent className="p-6">
        <div className="space-y-4">
          {services.map((service) => (
            <div key={service.name} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="flex items-center">
                <CheckCircle className={`mr-3 h-5 w-5 ${service.status === 'operational' ? 'text-green-500' : 'text-amber-500'}`} />
                <div>
                  <h3 className="font-medium">{service.name}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Last checked: {formatDistanceToNow(new Date(service.lastChecked))}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-sm font-medium ${service.status === 'operational' ? 'text-green-500' : 'text-amber-500'}`}>
                  {service.status === 'operational' ? 'Operational' : service.status === 'degraded' ? 'Degraded' : 'Down'}
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400">
                  Response time: {service.responseTime}ms
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 flex items-center justify-between">
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Last full system check: <span className="font-medium">{formattedLastCheck}</span>
          </div>
          <Button 
            variant="outline" 
            className="text-primary bg-primary bg-opacity-10 hover:bg-opacity-20"
            onClick={() => runHealthCheck()}
            disabled={isPending}
          >
            <Repeat className="h-4 w-4 mr-1" />
            Run Health Check
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default HealthMonitor;