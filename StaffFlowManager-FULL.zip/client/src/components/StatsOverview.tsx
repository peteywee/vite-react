import { Card, CardContent } from "@/components/ui/card";
import { 
  Users, 
  Calendar, 
  Briefcase, 
  Activity,
  ArrowUp,
  ArrowDown,
  CheckCircle
} from "lucide-react";

interface Stat {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBgClass: string;
  iconTextClass: string;
  change?: {
    value: string;
    positive: boolean;
  };
  subtext?: string;
}

interface StatsOverviewProps {
  stats: Stat[];
}

const DEFAULT_STATS: Stat[] = [
  {
    title: "Total Staff",
    value: "87",
    icon: <Users className="h-5 w-5" />,
    iconBgClass: "bg-blue-100 dark:bg-blue-900",
    iconTextClass: "text-primary",
    change: {
      value: "12%",
      positive: true
    }
  },
  {
    title: "Active Schedules",
    value: "42",
    icon: <Calendar className="h-5 w-5" />,
    iconBgClass: "bg-green-100 dark:bg-green-900",
    iconTextClass: "text-secondary",
    change: {
      value: "8%",
      positive: true
    }
  },
  {
    title: "Open Positions",
    value: "14",
    icon: <Briefcase className="h-5 w-5" />,
    iconBgClass: "bg-yellow-100 dark:bg-yellow-900",
    iconTextClass: "text-warning",
    change: {
      value: "5%",
      positive: false
    }
  },
  {
    title: "System Health",
    value: "100%",
    icon: <Activity className="h-5 w-5" />,
    iconBgClass: "bg-purple-100 dark:bg-purple-900",
    iconTextClass: "text-accent",
    subtext: "All systems operational"
  }
];

const StatsOverview = ({ stats = DEFAULT_STATS }: StatsOverviewProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{stat.title}</p>
                <h3 className="text-2xl font-semibold">{stat.value}</h3>
              </div>
              <div className={`w-12 h-12 rounded-full ${stat.iconBgClass} ${stat.iconTextClass} flex items-center justify-center`}>
                {stat.icon}
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              {stat.change ? (
                <>
                  <span className={`flex items-center ${stat.change.positive ? 'text-green-500' : 'text-red-500'}`}>
                    {stat.change.positive ? 
                      <ArrowUp className="h-4 w-4 mr-1" /> : 
                      <ArrowDown className="h-4 w-4 mr-1" />
                    }
                    <span>{stat.change.value}</span>
                  </span>
                  <span className="text-gray-500 dark:text-gray-400 ml-2">vs last month</span>
                </>
              ) : stat.subtext ? (
                <span className="text-green-500 flex items-center">
                  <CheckCircle className="h-4 w-4 mr-1" />
                  <span>{stat.subtext}</span>
                </span>
              ) : null}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default StatsOverview;
