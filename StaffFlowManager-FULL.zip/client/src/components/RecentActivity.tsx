import { 
  Card, 
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter 
} from "@/components/ui/card";
import { UserPlus, Edit, CalendarDays, Activity, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Activity as ActivityType } from "@/types";

interface RecentActivityProps {
  activities: ActivityType[];
}

const ActivityIcon = ({ type }: { type: string }) => {
  const iconMap: Record<string, { icon: React.ReactNode, bgColor: string, textColor: string }> = {
    "staff_added": { 
      icon: <UserPlus className="h-4 w-4" />, 
      bgColor: "bg-blue-100 dark:bg-blue-900", 
      textColor: "text-primary" 
    },
    "profile_updated": { 
      icon: <Edit className="h-4 w-4" />, 
      bgColor: "bg-green-100 dark:bg-green-900", 
      textColor: "text-green-600" 
    },
    "schedule_created": { 
      icon: <CalendarDays className="h-4 w-4" />, 
      bgColor: "bg-yellow-100 dark:bg-yellow-900", 
      textColor: "text-yellow-600" 
    },
    "health_check": { 
      icon: <Activity className="h-4 w-4" />, 
      bgColor: "bg-red-100 dark:bg-red-900", 
      textColor: "text-red-600" 
    }
  };

  const { icon, bgColor, textColor } = iconMap[type] || iconMap["health_check"];

  return (
    <span className={cn(
      "h-8 w-8 rounded-full flex items-center justify-center ring-8 ring-white dark:ring-gray-900",
      bgColor,
      textColor
    )}>
      {icon}
    </span>
  );
};

const RecentActivity = ({ activities }: RecentActivityProps) => {
  return (
    <Card className="lg:col-span-1">
      <CardHeader className="border-b border-gray-200 dark:border-gray-700 p-6">
        <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="flow-root">
          <ul className="-mb-8">
            {activities.map((activity, index) => (
              <li key={activity.id}>
                <div className="relative pb-8">
                  {index < activities.length - 1 && (
                    <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200 dark:bg-gray-700"></span>
                  )}
                  <div className="relative flex space-x-3">
                    <div>
                      <ActivityIcon type={activity.type} />
                    </div>
                    <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                      <div>
                        <p className="text-sm text-gray-800 dark:text-gray-200" dangerouslySetInnerHTML={{ __html: activity.message }}></p>
                      </div>
                      <div className="text-right text-xs text-gray-500 dark:text-gray-400">
                        <span>{activity.timeAgo}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="mt-6">
          <Link href="/activities">
            <a className="text-sm font-medium text-primary hover:text-primary-dark flex items-center">
              View all activity
              <ArrowRight className="h-4 w-4 ml-1" />
            </a>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentActivity;
