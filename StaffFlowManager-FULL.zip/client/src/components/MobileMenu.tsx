import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  BarChart, 
  Settings, 
  ShieldCheck, 
  Lock, 
  Activity,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileMenu = ({ isOpen, onClose }: MobileMenuProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-gray-900 bg-opacity-50" onClick={onClose}></div>
      <div className="absolute top-0 left-0 w-64 h-full bg-white dark:bg-gray-900 shadow-lg transform">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
              <Users className="h-4 w-4" />
            </div>
            <h1 className="text-lg font-semibold">StaffFlowTX</h1>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <nav className="p-2">
          <div className="space-y-1">
            <NavLink href="/" icon={<LayoutDashboard className="mr-3 h-4 w-4" />} active onNavigate={onClose}>Dashboard</NavLink>
            <NavLink href="/staff" icon={<Users className="mr-3 h-4 w-4" />} onNavigate={onClose}>Staff</NavLink>
            <NavLink href="/schedules" icon={<Calendar className="mr-3 h-4 w-4" />} onNavigate={onClose}>Schedules</NavLink>
            <NavLink href="/reports" icon={<BarChart className="mr-3 h-4 w-4" />} onNavigate={onClose}>Reports</NavLink>
            <NavLink href="/settings" icon={<Settings className="mr-3 h-4 w-4" />} onNavigate={onClose}>Settings</NavLink>
          </div>
          
          <div className="mt-8 pt-4 border-t border-gray-200 dark:border-gray-700">
            <h3 className="px-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">Admin</h3>
            <div className="mt-2 space-y-1">
              <NavLink href="/users" icon={<ShieldCheck className="mr-3 h-4 w-4" />} onNavigate={onClose}>User Management</NavLink>
              <NavLink href="/permissions" icon={<Lock className="mr-3 h-4 w-4" />} onNavigate={onClose}>Permissions</NavLink>
              <NavLink href="/health-check" icon={<Activity className="mr-3 h-4 w-4" />} onNavigate={onClose}>Health Check</NavLink>
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
};

interface NavLinkProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  active?: boolean;
  onNavigate?: () => void;
}

const NavLink = ({ href, icon, children, active, onNavigate }: NavLinkProps) => {
  return (
    <Link href={href}>
      <a 
        className={cn(
          "flex items-center p-2 rounded-md",
          active ? "bg-primary bg-opacity-10 text-primary" : "hover:bg-gray-100 dark:hover:bg-gray-800"
        )}
        onClick={onNavigate}
      >
        {icon}
        {children}
      </a>
    </Link>
  );
};

export default MobileMenu;
