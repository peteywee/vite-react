import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").$type<"admin" | "staff">().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Staff table
export const staffTable = pgTable("staff", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  position: text("position").notNull(),
  department: text("department").notNull(),
  status: text("status").notNull().$type<"active" | "inactive" | "on leave">(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// System health monitoring
export const healthChecks = pgTable("health_checks", {
  id: serial("id").primaryKey(),
  serviceName: text("service_name").notNull(),
  status: text("status").$type<"operational" | "degraded" | "down">().notNull(),
  lastChecked: timestamp("last_checked").notNull(),
  responseTime: integer("response_time").notNull(),
  message: text("message"),
});

// Activity logs
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(),
  details: text("details"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Export types
export type User = typeof users.$inferSelect;
export type Staff = typeof staffTable.$inferSelect;
export type HealthCheck = typeof healthChecks.$inferSelect;
export type ActivityLog = typeof activityLogs.$inferSelect;

// Validation schemas
export const insertUserSchema = createInsertSchema(users);
export const insertStaffSchema = createInsertSchema(staffTable);
export const insertHealthCheckSchema = createInsertSchema(healthChecks);
export const insertActivityLogSchema = createInsertSchema(activityLogs);