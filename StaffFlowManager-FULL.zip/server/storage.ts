
import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { sql } from 'drizzle-orm';
import * as schema from '@shared/schema';
import { users, type User, type Staff, type HealthCheck, type ActivityLog } from "@shared/schema";
import { insertUserSchema, insertStaffSchema, insertHealthCheckSchema, insertActivityLogSchema } from "@shared/schema";
import { staffTable, healthChecks, activityLogs } from "@shared/schema";
import { eq, count } from 'drizzle-orm';
const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL environment variable is required');
}

// Parse the DATABASE_URL value which appears to be in command-line format
const dbUrl = process.env.DATABASE_URL;
console.log('Connecting to database:', dbUrl);

// Function to extract connection details from command line format
function parseConnectionString(str: string) {
  const hostMatch = /-h\s+([^\s]+)/.exec(str);
  const portMatch = /-p\s+(\d+)/.exec(str);
  const dbMatch = /-d\s+([^\s]+)/.exec(str);
  const userMatch = /-U\s+([^\s]+)/.exec(str);

  return {
    host: hostMatch ? hostMatch[1] : undefined,
    port: portMatch ? parseInt(portMatch[1], 10) : 5432,
    database: dbMatch ? dbMatch[1] : undefined,
    user: userMatch ? userMatch[1] : undefined,
    // Note: password would need to be provided separately
    password: "postgres" // Using default Supabase password as fallback
  };
}

// Try to parse the connection string if it's in command line format
const connectionInfo = dbUrl.includes('-h') 
  ? parseConnectionString(dbUrl)
  : { connectionString: dbUrl };
  
// Safe logging of connection info
if ('connectionString' in connectionInfo) {
  console.log('Using connection string format');
} else {
  console.log('Parsed connection info:', { 
    host: connectionInfo.host || 'Not provided',
    database: connectionInfo.database || 'Not provided'
  });
}

// Create the pool with the parsed connection info
const pool = new Pool({
  ...(dbUrl.includes('-h') ? connectionInfo : { connectionString: dbUrl }),
  ssl: {
    rejectUnauthorized: false
  },
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
});

export const db = drizzle(pool, { schema });

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: typeof insertUserSchema._type): Promise<User>;
  
  // Staff operations
  getAllStaff(): Promise<Staff[]>;
  getStaffCount(): Promise<number>;
  getStaff(id: number): Promise<Staff | undefined>;
  createStaff(staff: typeof insertStaffSchema._type): Promise<Staff>;
  
  // Health check operations
  getHealthChecks(): Promise<HealthCheck[]>;
  createHealthCheck(healthCheck: typeof insertHealthCheckSchema._type): Promise<HealthCheck>;
  
  // Activity log operations
  getRecentActivityLogs(limit: number): Promise<ActivityLog[]>;
  createActivityLog(activityLog: typeof insertActivityLogSchema._type): Promise<ActivityLog>;
}

export class PostgresStorage implements IStorage {
    // User operations
    async getUser(id: number): Promise<User | undefined> {
        return db.query.users.findFirst({
            where: (u) => eq(u.id, id)
        });
    }

    async getUserByEmail(email: string): Promise<User | undefined> {
        return db.query.users.findFirst({
            where: (u) => eq(u.email, email)
        });
    }

    async createUser(user: typeof insertUserSchema._type): Promise<User> {
        const result = await db.insert(users).values([user as any]).returning();
        return result[0];
    }
    
    // Staff operations
    async getAllStaff(): Promise<Staff[]> {
        return db.query.staffTable.findMany();
    }
    
    async getStaffCount(): Promise<number> {
        const result = await db.select({ count: sql`count(*)` }).from(staffTable);
        return Number(result[0].count);
    }
    
    async getStaff(id: number): Promise<Staff | undefined> {
        return db.query.staffTable.findFirst({
            where: (s) => eq(s.id, id)
        });
    }
    
    async createStaff(staff: typeof insertStaffSchema._type): Promise<Staff> {
        const result = await db.insert(staffTable).values([staff as any]).returning();
        return result[0];
    }
    
    // Health check operations
    async getHealthChecks(): Promise<HealthCheck[]> {
        return db.query.healthChecks.findMany({
            orderBy: (hc) => hc.lastChecked,
            limit: 10
        });
    }
    
    async createHealthCheck(healthCheck: typeof insertHealthCheckSchema._type): Promise<HealthCheck> {
        const result = await db.insert(healthChecks).values([healthCheck as any]).returning();
        return result[0];
    }
    
    // Activity log operations
    async getRecentActivityLogs(limit: number = 5): Promise<ActivityLog[]> {
        return db.query.activityLogs.findMany({
            orderBy: (al) => al.timestamp,
            limit
        });
    }
    
    async createActivityLog(activityLog: typeof insertActivityLogSchema._type): Promise<ActivityLog> {
        const result = await db.insert(activityLogs).values([activityLog as any]).returning();
        return result[0];
    }
}

export const storage = new PostgresStorage();
