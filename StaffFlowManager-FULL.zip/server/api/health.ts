import { db } from '../storage';
import { healthChecks } from '@shared/schema';
import { eq, sql } from 'drizzle-orm';
import express from 'express';
const router = express.Router();

export async function checkHealth() {
  const services = [
    { name: 'Database', check: checkDatabase },
    { name: 'API', check: checkAPI },
    // Add more services as needed
  ];

  const results = await Promise.all(services.map(s => performHealthCheck(s)));
  return results;
}

async function performHealthCheck({ name, check }: { name: string; check: () => Promise<boolean> }) {
  const startTime = Date.now();
  try {
    const isHealthy = await check();
    const responseTime = Date.now() - startTime;

    await db.insert(healthChecks).values({
      serviceName: name,
      status: isHealthy ? 'operational' : 'degraded',
      lastChecked: new Date(),
      responseTime,
      message: isHealthy ? 'Service is operational' : 'Service is degraded'
    });

    return {
      name,
      status: isHealthy ? 'operational' : 'degraded',
      lastChecked: new Date().toISOString(),
      responseTime
    };
  } catch (error) {
    await db.insert(healthChecks).values({
      serviceName: name,
      status: 'down',
      lastChecked: new Date(),
      responseTime: Date.now() - startTime,
      message: error instanceof Error ? error.message : 'Unknown error'
    });

    return {
      name,
      status: 'down',
      lastChecked: new Date().toISOString(),
      responseTime: Date.now() - startTime
    };
  }
}

async function checkDatabase() {
  try {
    // Try a simpler query first to verify database connectivity
    try {
      await db.execute(sql`SELECT 1 as health_check`);
      console.log('Database connection check successful');
      return true;
    } catch (err: any) {
      console.error('Database connection check failed:', err?.message || String(err));
      return false;
    }
  } catch (error) {
    console.error('General error in database health check:', error);
    return false;
  }
}

async function checkAPI() {
  // Implement API health check
  return true;
}

// Health check endpoints
router.get('/', async (_req, res) => {
  try {
    const results = await checkHealth();
    res.json(results);
  } catch (error) {
    console.error('Error in health check endpoint:', error);
    res.status(500).json({
      status: 'error',
      message: 'Failed to perform health check',
      error: error instanceof Error ? error.message : String(error)
    });
  }
});

export { router as default };