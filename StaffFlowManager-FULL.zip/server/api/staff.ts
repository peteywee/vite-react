import { Router, Request, Response } from "express";
import { storage } from "../storage";
import { z } from "zod";
import { Staff, insertStaffSchema } from "@shared/schema";

const router = Router();

// Mock data for now
const mockStaff: Staff[] = [
  {
    id: 1,
    name: "Jane Doe",
    email: "jane.doe@example.com",
    position: "Senior Developer",
    department: "Engineering",
    status: "active"
  },
  {
    id: 2,
    name: "John Smith",
    email: "john.smith@example.com",
    position: "UI Designer",
    department: "Design",
    status: "active"
  },
  {
    id: 3,
    name: "Alice Johnson",
    email: "alice.j@example.com",
    position: "Project Manager",
    department: "Management",
    status: "on leave"
  },
  {
    id: 4,
    name: "Robert Brown",
    email: "robert.b@example.com",
    position: "DevOps Engineer",
    department: "Infrastructure",
    status: "inactive"
  }
];

// GET /api/staff - Get all staff members
router.get("/", (req: Request, res: Response) => {
  // In a real app, we would use the storage interface
  // const staff = await storage.getAllStaff();
  
  res.status(200).json({
    staff: mockStaff,
    total: 87
  });
});

// GET /api/staff/:id - Get a specific staff member
router.get("/:id", (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const staff = mockStaff.find(s => s.id === id);
  
  if (!staff) {
    return res.status(404).json({
      message: "Staff member not found"
    });
  }
  
  res.status(200).json(staff);
});

// POST /api/staff - Create a new staff member
router.post("/", async (req: Request, res: Response) => {
  try {
    const staffData = insertStaffSchema.parse(req.body);
    
    // In a real app, we would use the storage interface
    // const staff = await storage.createStaff(staffData);
    
    const newStaff = {
      id: mockStaff.length + 1,
      ...staffData
    };
    
    res.status(201).json(newStaff);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        message: "Invalid staff data",
        errors: error.errors
      });
    }
    
    res.status(500).json({
      message: "Failed to create staff member"
    });
  }
});

export default router;
