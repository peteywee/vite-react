import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import healthRoutes from "./api/health";
import staffRoutes from "./api/staff";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health routes for monitoring
  app.use("/api/health", healthRoutes);
  
  // Staff management routes
  app.use("/api/staff", staffRoutes);
  
  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
