import { describe, it, expect } from 'vitest';

describe('Basic sanity test', () => {
  it('should return true', () => {
    expect(true).toBe(true);
  });
});
