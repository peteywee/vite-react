import React from 'react';

export const ClockInOut = () => {
  return <div className="p-4 text-white bg-gray-700 rounded">🕒 Clock In/Out Component</div>;
};
