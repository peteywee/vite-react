import React from 'react';

export const Calendar = () => {
  return <div className="p-4 text-white bg-gray-800 rounded">📅 Calendar View (Coming Soon)</div>;
};
