#!/usr/bin/env bash
set -euo pipefail

echo "🔧 Bootstrapping StaffFlowTX in Replit..."

if [ ! -d "node_modules" ]; then
  yarn install --immutable
fi

# Ensure .env file exists
if [ ! -f ".env" ]; then
  echo "Creating .env file from .env.example..."
  cp .env.example .env || echo "No .env.example found, creating empty .env"
  touch .env
fi

echo "🧪 Running linting and checks..."
yarn check

echo "🚀 Starting dev server..."
yarn dev
